package codingwithmitch.com.databindinggettingstarted;

public interface IMainActivity {

    void inflateQuantityDialog();

    void setQuantity(int quantity);
}
